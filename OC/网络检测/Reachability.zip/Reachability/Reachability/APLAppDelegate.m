/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Application delegate class.
 */

#import "APLAppDelegate.h"

@implementation APLAppDelegate

@end
