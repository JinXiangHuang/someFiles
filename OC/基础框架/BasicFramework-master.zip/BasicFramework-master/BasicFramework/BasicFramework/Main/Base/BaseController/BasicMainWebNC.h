//
//

#import <UIKit/UIKit.h>

@interface BasicMainWebNC : UINavigationController

@end
