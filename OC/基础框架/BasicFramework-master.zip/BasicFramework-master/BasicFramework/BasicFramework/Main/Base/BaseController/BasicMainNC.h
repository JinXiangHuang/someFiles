//
//

#import <UIKit/UIKit.h>

@interface BasicMainNC : UINavigationController

@end
