
//

#import <UIKit/UIKit.h>

@interface LYLPageControl : UIPageControl

@end
