//

#import <UIKit/UIKit.h>
#import "NSObject+NSCoding.h"
//! Project version number for MyObjectCoding.
FOUNDATION_EXPORT double MyObjectCodingVersionNumber;

//! Project version string for MyObjectCoding.
FOUNDATION_EXPORT const unsigned char MyObjectCodingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyObjectCoding/PublicHeader.h>


