//
//

#ifndef CommonAppKey_h
#define CommonAppKey_h

/* 使用高德地图API，请注册Key，注册地址：http://lbs.amap.com/console/key */

const static NSString *APIKey = @"80499cd66f9af6a6465ba4090549232a";




#endif /* CommonAppKey_h */
