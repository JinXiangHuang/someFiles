//
//  Constants.h
//  BasicFramework
//
//  Created by Rainy on 16/8/18.
//  Copyright © 2016年 Rainy. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

//邮件接收人
static NSString* const kMail_cc_ToRecipients_Address=@"mobileproject@126.com";


#endif /* Constants_h */
