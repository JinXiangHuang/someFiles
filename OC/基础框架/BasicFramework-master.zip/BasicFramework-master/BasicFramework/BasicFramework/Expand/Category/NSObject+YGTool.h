//
//

#import <Foundation/Foundation.h>

@interface NSObject (YGTool)
+ (UIViewController*)viewControllerWithviewObj:(UIView *)viewObj;//获取view的所在父ViewController

@end
