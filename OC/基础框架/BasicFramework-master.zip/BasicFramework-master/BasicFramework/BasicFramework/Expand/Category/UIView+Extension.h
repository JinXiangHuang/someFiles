
#import <UIKit/UIKit.h>

@interface UIView (Extension)

@property(nonatomic)CGFloat cornerRad;
@property(nonatomic)CGFloat Cy;
@property(nonatomic)CGFloat Cx;

@property(nonatomic,assign)CGFloat X;
@property(nonatomic,assign)CGFloat Y;
@property(nonatomic,assign)CGFloat Sh;
@property (nonatomic, assign)CGSize size;
@property(nonatomic,assign)CGFloat Sw;



@end
