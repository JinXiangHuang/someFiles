//
//  AppDelegate.h
//  HXInternationalizationDemo https://github.com/huangxuan518/HXInternationalizationDemo
//  博客地址 http://blog.libuqing.com/
//  Created by 黄轩 on 16/7/28.
//  Copyright © 2016年 黄轩. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

