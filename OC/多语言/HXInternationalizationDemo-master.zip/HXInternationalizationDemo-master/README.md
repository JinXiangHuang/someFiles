# HXInternationalizationDemo 如果对你有一点点帮助,请给一颗★,你的支持是对我的最大鼓励！
国际化示例demo

# 在线预览
https://appetize.io/app/0pwu711y0avbvyv2xymepymf1c

# 博客交流

http://blog.libuqing.com/
